This program simulates the sound made from plucking a guitar string. The following string denotes all the keys that can be pressed to generate a different sound: q2we4r5ty7u8i9op-[=zxdcfvgbnjmk,.;/' 

This program can be run by typing java -jar GuitarHero.jar into the command line.
