#ifndef bisonHelper_h
#define bisonHelper_h

#include "ast.h"

void assignStmtTargets(struct ast_expression *root, struct symbol_table_entry *target);
#endif /** bisonHelper_h */
