import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*
 * Epsilon transitions are stored as E.
 */

public class DFA {
	public String[][] states; // Stores each state plus transitions to other states.
	public String[] alphabet; // Alphabet of our DFA
	public boolean[] finishStates;

	public DFA(int numStates) {
		this.states = new String[numStates][numStates];
		this.finishStates = new boolean[numStates];
	}
	public DFA(String[][] states, boolean[] finishStates) {
		this.states = states;
		this.finishStates = finishStates;
	}
	public DFA(String[][] states, boolean[] finishStates, String[] alphabet) {
		this.states = states;
		this.finishStates = finishStates;
		this.alphabet = alphabet;
	}
	public void setAlphabet(String[] array) {
		this.alphabet = array;
	}
	public void printAlphabet() {
		for(int i = 0; i < this.alphabet.length; i++) {
			System.out.println(this.alphabet[i]);
		}
	}
	public void insertState(int stateNum, boolean isFinishState) {
		// This function is mainly used to add finished states to the DFA.
		finishStates[stateNum] = isFinishState;
	}
	public void insertTransition(int state1, String transition, int state2) {
		states[state1][state2] = transition;
	}
	/*
	 * TODO
	 * Write a print state table function like in example 2 of lecture 3 (slide 22).
	 */
	public void prettyPrint() {
		System.out.printf("%15s", "States");
		for(String a: this.alphabet)
			System.out.printf("%15s", a);
		System.out.println();
		for(int i = 0; i < this.states.length; i++) {
			System.out.printf("%15s", i);
			for(int j = 0; j < this.states[i].length; j++) {
				for(String a: this.alphabet) {
					if(this.states[i][j] != null) {
						if(this.states[i][j].contains(a)) {
							System.out.printf("%15s", j);
						}
					}
				}
			}
			System.out.println();
		}
		//		for(String a: this.alphabet) {
		//			for(int i = 0; i < this.states.length; i++) {
		//				System.out.printf("%15s", i);
		//				for(int j = 0; j < this.states[i].length; j++) {
		//					if(this.states[i][j] != null) {
		//						if(this.states[i][j].equals(a)) {
		//							System.out.printf("%15s", j);
		//						}
		//					}
		//				}
		//				System.out.println();
		//			}
		//		}
	}
	public void printStates() {
		for(int i = 0; i < this.states.length; i++) {
			System.out.printf("State %d has transitions to the following states:\n", i);
			for(int j = 0; j < this.states[i].length; j++) {
				if(this.states[i][j] != null)
					System.out.printf("State %d with the following transition: %s\n", j, this.states[i][j]);
			}
			if(this.finishStates[i])
				System.out.printf("State %d is also a finish state.\n", i);
		}
	}
	public int getNumStates() {
		return this.states.length;
	}
	// Calculate the epsilon closure of a state.
	public ArrayList<Integer> EClosure(int state) {
		ArrayList<Integer> states = new ArrayList<>();
		states.add(state);
		for(int i = 0; i < this.states[state].length; i++) {
			if(this.states[state][i] != null) {
				if(this.states[state][i].equals("E")) {
					// Look at this state
					states.add(i);
					ArrayList<Integer> nextState = EClosure(i);
					if(nextState.size() > 1) {
						for(Integer a: nextState) {
							if(!states.contains(a)) 
								states.add(a);
						}
					}
				}
			}
		}
		states.sort(null);
		return states;
	}
	/*
	 * This method is used for NFA's that have Epsilon transitions.
	 */
	public void ENFAtoDFA() {
		ArrayList<String> pSet = new ArrayList<>();
		// Generates a set of strings that can be used to determine which elements should be looked at for our subset sum problem
		// Ex: n = 3: sets = { 000, 001, 010, 011, 100, 101, 110, 111 };
		pSet.clear();
		for(int i = 0; i < (int)Math.pow(2, this.getNumStates()); i++) {
			pSet.add(new StringBuilder(Integer.toString(i,2)).reverse().toString());
		}
		//		System.out.println(pSet);
		// Standardize the strings.
		for(int i = 0; i < pSet.size(); i++) {
			if(pSet.get(i).length() < this.getNumStates()) {
				StringBuilder sb = new StringBuilder(pSet.get(i));
				for(int j = 0; j < this.getNumStates()-pSet.get(i).length(); j++) {
					sb.append("0");
				}
				pSet.set(i, sb.toString());
			}
		}
		//		System.out.println(pSet);
		for(int i = 0; i < pSet.size(); i++) {
			String tmp = "";
			for(int j = 0; j < pSet.get(i).length(); j++) {
				if(pSet.get(i).charAt(j) == '1')
					tmp += ""+(j);
			}
			pSet.set(i, tmp);
		}
		Map<List<Integer>, List<Integer>> stateTable = new HashMap<List<Integer>, List<Integer>>(); // Will hold the new sets of states
		//		stateHolder[0] = "Null";
		int counter = 0;
		int alphabetLength = this.alphabet.length; // This will be used to keep not process Epsilon if it is present.
		for(int i = 0; i < this.alphabet.length; i++) {
			if(this.alphabet[i].equals("E")) {
				alphabetLength -= 1;
				break;
			}
		}


		ArrayList<Integer> q_0 = EClosure(0);
		List<Map> stateHolder = new ArrayList<>(); // Print these in order
		for(String a: this.alphabet) {
			String[] arr;
			for(int i = 1; i < pSet.size(); i++) {
				arr = pSet.get(i).split("");
				// Temp holds combinations of states
				ArrayList<Integer> temp = new ArrayList<>();
				for(int j = 0; j < arr.length; j++) {
					temp.add(Integer.parseInt(arr[j]));
				}
				// The states in temp now need to have their transitions added to the map.
				ArrayList<Integer> tempTransitions = new ArrayList<>();
				for(int j = 0; j < temp.size(); j++) {
					for(int k = 0; k < this.states[temp.get(j)].length; k++) {
						if(this.states[temp.get(j)][k] != null) {
							if((this.states[temp.get(j)][k].contains(a)) && !tempTransitions.contains(k)) {
								tempTransitions.add(k);
							}
						}
					}
				}
				ArrayList<Integer> tmp = new ArrayList<>();
				tmp.add(0);
				boolean changed = false;
				if(tempTransitions.equals(tmp)) {
					changed = true;
					tempTransitions = q_0;
				}
				if(changed) {
					ArrayList<Integer> tempEClosed = new ArrayList<>();
					for(Integer q: tempTransitions) {
						tmp = EClosure(q);
						if(tmp.size() > 1) {
							for(Integer q2: tmp)
								if(!tempEClosed.contains(q2))
									tempEClosed.add(q2);
						}
					}

					if(tempEClosed.size() > 0)
						tempTransitions = tempEClosed;
				}
				Collections.sort(tempTransitions);
				stateTable.put(temp, tempTransitions);
			}
			stateHolder.add(stateTable);
			stateTable = new HashMap<List<Integer>,List<Integer>>(); // Map.clear() would clear them in the previous list. Just make a new class and let GC deal with it later.
		}
		System.out.printf("%15s", "States");
		for(String a: alphabet) {
			if(a.equals("E")) continue;
			System.out.printf("%15s", a);
		}
		Set<List<Integer>> keySet = stateHolder.get(0).keySet(); // Holds each set of states
		ArrayList<List<Integer>> ksList = new ArrayList<>(); // Used because an arraylist is more manageable than a set.
		Iterator<List<Integer>> kIterator = keySet.iterator();
		while(kIterator.hasNext())
			ksList.add(kIterator.next());
		System.out.println();
		for(int i = 0; i < stateHolder.get(0).size(); i++) {
			System.out.printf("%15s", ksList.get(i));
			for(int j = 0; j < stateHolder.size()-1; j++) {
				System.out.printf("%15s", stateHolder.get(j).get(ksList.get(i)));
			}
			System.out.println();
		}
		System.out.printf("%15s%15s%15s", "[]","[]","[]");
		// Print finish states
		System.out.println();
		for(List<Integer> a: ksList) {
			for(int i = 0; i < this.finishStates.length; i++) {
				if(this.finishStates[i]) {
					if(a.contains(i)) {
						System.out.println(a + " is a finish state.");
						break;
					}
				}
			}
		}
	}
	/*
	 * This method is used for NFA's that do not have Epsilon transitions.
	 */
	public void NFAtoDFA() {
		// POWER SET CONSTRUCTION:
		ArrayList<String> pSet = new ArrayList<>();
		// Generates a set of strings that can be used to determine which elements should be looked at for our subset sum problem
		// Ex: n = 3: sets = { 000, 001, 010, 011, 100, 101, 110, 111 };
		pSet.clear();
		for(int i = 0; i < (int)Math.pow(2, this.getNumStates()); i++) {
			pSet.add(new StringBuilder(Integer.toString(i,2)).reverse().toString());
		}
		// Standardize the strings.
		for(int i = 0; i < pSet.size(); i++) {
			if(pSet.get(i).length() < this.getNumStates()) {
				StringBuilder sb = new StringBuilder(pSet.get(i));
				for(int j = 0; j < this.getNumStates()-pSet.get(i).length(); j++) {
					sb.append("0");
				}
				pSet.set(i, sb.toString());
			}
		}
		for(int i = 0; i < pSet.size(); i++) {
			String tmp = "";
			for(int j = 0; j < pSet.get(i).length(); j++) {
				if(pSet.get(i).charAt(j) == '1')
					tmp += ""+(j);
			}
			pSet.set(i, tmp);
		}
		
		Map<List<Integer>, List<Integer>> stateTable = new HashMap<List<Integer>, List<Integer>>(); // Will hold the new sets of states
		int counter = 0;
		int alphabetLength = this.alphabet.length; // This will be used to keep not process Epsilon if it is present.
		for(int i = 0; i < this.alphabet.length; i++) {
			if(this.alphabet[i].equals("E")) {
				alphabetLength -= 1;
				break;
			}
		}
		
		List<Map> stateHolder = new ArrayList<>(); // Print these in order
		for(String a: this.alphabet) {
			String[] arr;
			for(int i = 1; i < pSet.size(); i++) {
				arr = pSet.get(i).split("");
				// Temp holds combinations of states
				ArrayList<Integer> temp = new ArrayList<>();
				for(int j = 0; j < arr.length; j++) {
					temp.add(Integer.parseInt(arr[j]));
				}
				// The states in temp now need to have their transitions added to the map.
				ArrayList<Integer> tempTransitions = new ArrayList<>();
				for(int j = 0; j < temp.size(); j++) {
					for(int k = 0; k < this.states[temp.get(j)].length; k++) {
						if(this.states[temp.get(j)][k] != null) {
							if((this.states[temp.get(j)][k].contains(a)/*||this.states[temp.get(j)][k].equals("E")*/) && !tempTransitions.contains(k)) {
								//								System.out.println(this.states[temp.get(j)][k]);
								//								System.out.println(k);
								tempTransitions.add(k);
							}
						}
					}
				}
				Collections.sort(tempTransitions);
				stateTable.put(temp, tempTransitions);
				//				System.out.println(stateTable);
				//				System.out.println(temp);
			}
			stateHolder.add(stateTable);
			stateTable = new HashMap<List<Integer>,List<Integer>>(); // Map.clear() would clear them in the previous list. Just make a new class and let GC deal with it later.

			//			System.out.println();
		}
		System.out.printf("%15s", "States");
		for(String a: alphabet) {
			if(a.equals("E")) continue;
			System.out.printf("%15s", a);
		}
		//		System.out.println(stateHolder);
		Set<List<Integer>> keySet = stateHolder.get(0).keySet(); // Holds each set of states
		ArrayList<List<Integer>> ksList = new ArrayList<>(); // Used because an arraylist is more manageable than a set.
		Iterator<List<Integer>> kIterator = keySet.iterator();
		while(kIterator.hasNext())
			ksList.add(kIterator.next());
		//		System.out.println(ksList);
		System.out.println();
		for(int i = 0; i < stateHolder.get(0).size(); i++) {
			System.out.printf("%15s", ksList.get(i));
			for(int j = 0; j < stateHolder.size(); j++) {
				System.out.printf("%15s", stateHolder.get(j).get(ksList.get(i)));
			}
			System.out.println();
		}
		System.out.printf("%15s%15s%15s", "[]","[]","[]");
		//		System.out.println("Not E-NFA");
		// Print finish states
		System.out.println();
		for(List<Integer> a: ksList) {
			for(int i = 0; i < this.finishStates.length; i++) {
				if(this.finishStates[i]) {
					if(a.contains(i)) {
						System.out.println(a + " is a finish state.");
						break;
					}
				}
			}
		}
	}

	/*
	 * Union definition from the book:
	 * Q = {(r1,r2)|r1 E Q1 and r2 E Q2}. This is the Cartesian product of sets Q1 and Q2.
	 * The alphabet is assumed to be the same for both DFA's.
	 * Delta, the transition function, is defined as follows. For each (r1,r2) E Q
	 * and each a E Sigma, let Delta((r1,r2),a) = (Delta1(r1,a),Delta2(r2,a)).
	 * Hence Delta gets a state of M (which actually is a pair of states from M1 and M2),
	 * together with an input symbol, and returns M's next state.
	 * q0 is the pair (q1,q2).
	 * F is the set of pairs in which either member is an accept state of M1 or M2.
	 * We can write it as F = {(r1,r2) | r1 E F1 or r2 E F2}.
	 */
	public void UnionDictionary(DFA dfa2) {
		// These two dictionaries hold the transitions for each DFA.
		// The next set of loops will modify the dictionaries to show where each
		// DFA's states will transition upon receiving each symbol in their alphabet.
		Map<Integer, Integer> DFA1Dict = new HashMap<Integer, Integer>();
		Map<Integer, Integer> DFA2Dict = new HashMap<Integer, Integer>();
		// Not the best looking solution, but this ArrayList will hold the new sets of states.
		ArrayList<ArrayList<String>> stateHolder = new ArrayList<>();
		for(String a: alphabet) {
			// ArrayList temporarily holds the new states.
			ArrayList<String> newStates = new ArrayList<>();
			// DFA1
			for(int i = 0; i < this.states.length; i++) {
				for(int j = 0; j < this.states[i].length; j++) {
					if(this.states[i][j] != null) {
						if(this.states[i][j].contains(a)) {
							DFA1Dict.put(i, j);
						}
					}
				}
			}
			for(int i = 0; i < dfa2.states.length; i++) {
				for(int j = 0; j < dfa2.states[i].length; j++) {
					if(dfa2.states[i][j] != null) {
						if(dfa2.states[i][j].contains(a)) {
							DFA2Dict.put(i, j);
						}
					}
				}
			}
			//			System.out.println(DFA1Dict);
			//			System.out.println(DFA2Dict);
			for(int i = 0; i < DFA1Dict.size(); i++) {
				for(int j = 0; j < DFA2Dict.size(); j++) {
					newStates.add("(" + DFA1Dict.get(i) + ", " + DFA2Dict.get(j) + ")");
				}
			}
			//			System.out.println(newStates);
			stateHolder.add(newStates);
		}
		//		System.out.println(stateHolder);
		//		System.out.println(DFA1Dict);
		System.out.println("Output is styled as follows:\nAlphabet\nState Transition1 Transition2...");
		for(String a: alphabet) { // Print each symbol
			if(alphabet[0].equals(a))
				System.out.printf("%9s", a);
			else
				System.out.printf("%7s", a);
		}
		System.out.println();
		int[][] statePermutations = new int[this.getNumStates()*dfa2.getNumStates()][2];
		int counter = 0;
		for(int i = 0; i < this.getNumStates(); i++) {
			for(int j = 0; j < dfa2.getNumStates(); j++) {
				statePermutations[counter][0] = i;
				statePermutations[counter++][1] = j;
			}
		}
		for(int i = 0; i < stateHolder.get(0).size(); i++) {
			String transition = "(" + statePermutations[i][0] + ", " + statePermutations[i][1] + ")";
			for(int j = 0; j < this.alphabet.length; j++) {
				transition += " " + stateHolder.get(j).get(i);
			}
			System.out.println(transition);
		}
		// Print out the finish states:
		for(int i = 0; i < statePermutations.length; i++) {
			if(this.finishStates[statePermutations[i][0]] || dfa2.finishStates[statePermutations[i][1]]) {
				System.out.println("(" + statePermutations[i][0] + ", " + statePermutations[i][1] + ") is a finish state.");
			}
		}
	}

	/*
	 * I will not be adding empty transitions to the GNFA.
	 * I will assume that transitions have been specified in the following way:
	 * When prompted to enter transitions, if the user desires a state to have more than one
	 * transition to another state, they will be specified as follows: "a,b,..."
	 * This will be replaced as something like this: "a U b U ..."
	 */
	public DFA returnGNFA() {
		DFA GNFA = new DFA(this.getNumStates() + 2); // New start and accept states.
		GNFA.insertState(this.getNumStates()+1, true); // The only accept state will be the final state of the GNFA.
		GNFA.insertTransition(0, "E", 1);

		String[][] dfaStateCopy = this.states;
		// Next nested loop replaces comma's with unions.
		for(int i = 0; i < dfaStateCopy.length; i++) {
			for(int j = 0; j < dfaStateCopy[i].length; j++) {
				if(dfaStateCopy[i][j] != null) {
					dfaStateCopy[i][j] = dfaStateCopy[i][j].replaceAll(",", " U ");
				}
			}
		}

		boolean[] dfaFinishStateCopy = this.finishStates;
		for(int i = 0; i < dfaFinishStateCopy.length; i++) {
			if(dfaFinishStateCopy[i]) {
				GNFA.insertTransition(i+1, "E", this.getNumStates()+1); // Adds a transition from old finish states to the new finish finish state.
			}
		}
		// Next nested loop copies the old states to the GNFA.
		for(int i = 0; i < dfaStateCopy.length; i++) {
			for(int j = 0; j < dfaStateCopy[i].length; j++) {
				if(dfaStateCopy[i][j] != null) {
					GNFA.insertTransition(i+1, dfaStateCopy[i][j], j+1);
				}
			}
		}
		return GNFA;
	}

	/*
	 * Convert a GNFA to a Regular Expression
	 */
	public void convert() {
		for(int k = 0; k < this.getNumStates(); k++) {
			for(int i = k; i < this.getNumStates(); i++) {
				for(int j = k; j < this.getNumStates(); j++) {
					if(this.states[i][k] != null && this.states[k][j] != null) {
						String regularExpression = "";
						if(this.states[i][k] != null) regularExpression += "(" + this.states[i][k] + ")";
						if(this.states[k][k] != null) regularExpression += "(" + this.states[k][k] + ")*";
						if(this.states[k][j] != null) regularExpression += "(" + this.states[k][j] + ")";
						if(this.states[i][j] != null) regularExpression += " U (" + this.states[i][j] + ")";
						if(!regularExpression.equals("")) this.states[i][j] = regularExpression;
					}
				}
			}
		}
		String expression = "";
		for(int i = 0; i < this.states.length; i++) {
			for(int j = 0; j < this.states[i].length; j++) {
				if(this.states[i][j] != null) {
					expression = (this.states[i][j].length() > expression.length()) ? this.states[i][j]:expression;
				}
			}
		}
		System.out.println(expression);
	}
}
