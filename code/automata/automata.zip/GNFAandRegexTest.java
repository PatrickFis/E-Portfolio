import java.util.Scanner;

public class GNFAandRegexTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		DFA dfa1;
		System.out.println("Enter the alphabet for DFA1. Separate symbols should be separated by a comma.");
		String alphabet = sc.nextLine();
		System.out.println("Enter the total number of states for DFA1: ");
		int numStatesDFA1 = sc.nextInt();
		dfa1 = new DFA(numStatesDFA1);
		dfa1.setAlphabet(alphabet.split(","));
		System.out.println("Input finish states starting from 0 for DFA1. Exit with -1: ");
		while(true) {
			int finish = sc.nextInt();
			if(finish == -1)
				break;
			else dfa1.insertState(finish, true);
		}
		sc.nextLine(); // Get rid of extra newline
		System.out.println("Input transitions for DFA1 in the following format: State1 Transition State2. Exit with -1.");
		while(true) {
			String line = sc.nextLine();
			if(line.equals("-1"))
				break;
			String[] split = line.split(" "); // Split into three arguments
			dfa1.insertTransition(Integer.parseInt(split[0]), split[1], Integer.parseInt(split[2]));
		}
//		dfa1.printStates();
		dfa1.prettyPrint();
		DFA GNFA = dfa1.returnGNFA();
		System.out.println("GNFA's transitions: ");
		GNFA.printStates();
		System.out.println("Regular expression from GNFA:");
		GNFA.convert();
	}
}
