import java.util.Scanner;

public class NFAtoDFATest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		DFA nfa;
		System.out.println("Enter the alphabet for the NFA. Separate symbols should be separated by a comma."
				+ "\nSpecify Epsilon as E if it will be used.");
		String alphabet = sc.nextLine();
		System.out.println("Enter the total number of states for the NFA: ");
		int numStatesDFA1 = sc.nextInt();
		nfa = new DFA(numStatesDFA1);
		nfa.setAlphabet(alphabet.split(","));
		System.out.println("Input finish states starting from 0 for the NFA. Exit with -1: ");
		while(true) {
			int finish = sc.nextInt();
			if(finish == -1)
				break;
			else nfa.insertState(finish, true);
		}
		sc.nextLine(); // Get rid of extra newline
		System.out.println("Input transitions for the NFA in the following format: State1 Transition State2. Exit with -1.");
		while(true) {
			String line = sc.nextLine();
			if(line.equals("-1"))
				break;
			String[] split = line.split(" "); // Split into three arguments
			nfa.insertTransition(Integer.parseInt(split[0]), split[1], Integer.parseInt(split[2]));
		}
//		nfa.NFAtoDFA();
//		System.out.println(nfa.EClosure(0));
		if(alphabet.contains("E")) nfa.ENFAtoDFA();
		else nfa.NFAtoDFA();
	}

}
